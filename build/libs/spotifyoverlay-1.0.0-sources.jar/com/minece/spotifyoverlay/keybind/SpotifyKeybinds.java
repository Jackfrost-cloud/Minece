package com.minece.spotifyoverlay.keybind;

import com.minece.spotifyoverlay.SpotifyOverlayMod;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class SpotifyKeybinds {
    private static class_304 nextTrack;
    private static class_304 previousTrack;
    private static class_304 togglePlayback;
    private static class_304 openSpotify;
    private static class_304 toggleHud;

    public static void register() {
        nextTrack = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.spotifyoverlay.next",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            "category.spotifyoverlay"
        ));

        previousTrack = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.spotifyoverlay.previous",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            "category.spotifyoverlay"
        ));

        togglePlayback = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.spotifyoverlay.toggle_playback",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            "category.spotifyoverlay"
        ));

        openSpotify = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.spotifyoverlay.open",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            "category.spotifyoverlay"
        ));

        toggleHud = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.spotifyoverlay.toggle_hud",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            "category.spotifyoverlay"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (nextTrack.method_1436()) {
                SpotifyOverlayMod.apiClient.nextTrack();
            }
            while (previousTrack.method_1436()) {
                SpotifyOverlayMod.apiClient.previousTrack();
            }
            while (togglePlayback.method_1436()) {
                if (SpotifyOverlayMod.hudRenderer != null) {
                    SpotifyOverlayMod.hudRenderer.togglePlayback();
                }
            }
            while (openSpotify.method_1436()) {
                SpotifyOverlayMod.apiClient.openCurrentTrack();
            }
            while (toggleHud.method_1436()) {
                SpotifyOverlayMod.config.enabled = !SpotifyOverlayMod.config.enabled;
                SpotifyOverlayMod.config.save();
            }
        });
    }
}
