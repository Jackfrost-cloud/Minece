package com.minece.spotifyoverlay.hud;

import com.minece.spotifyoverlay.SpotifyOverlayMod;
import com.minece.spotifyoverlay.api.model.SpotifyPlayback;
import com.minece.spotifyoverlay.auth.SpotifyAuthManager;
import com.minece.spotifyoverlay.api.SpotifyApiClient;
import com.minece.spotifyoverlay.config.SpotifyModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class SpotifyHudRenderer implements HudRenderCallback {
    private static final int COVER_SIZE = 64;
    private static final int CARD_HEIGHT = 88;
    private static final int PADDING_X = 12;
    private static final int PADDING_Y = 12;

    private final SpotifyModConfig config;
    private final SpotifyAuthManager authManager;
    private final SpotifyApiClient apiClient;
    private SpotifyPlayback currentPlayback;
    private long lastFetchMs;

    public SpotifyHudRenderer(SpotifyModConfig config, SpotifyAuthManager authManager, SpotifyApiClient apiClient) {
        this.config = config;
        this.authManager = authManager;
        this.apiClient = apiClient;
    }

    @Override
    public void onHudRender(class_332 drawContext, float tickDelta) {
        if (!config.enabled || !authManager.isAuthenticated()) {
            return;
        }

        refreshIfNeeded();
        if (currentPlayback == null || !currentPlayback.hasTrack()) {
            drawEmptyState(drawContext);
            return;
        }

        drawCard(drawContext);
    }

    public void togglePlayback() {
        if (currentPlayback != null && currentPlayback.isPlaying()) {
            apiClient.pausePlayback();
        } else {
            apiClient.resumePlayback();
        }
        lastFetchMs = 0L;
    }

    private void refreshIfNeeded() {
        long now = System.currentTimeMillis();
        if (currentPlayback == null || now - lastFetchMs >= config.pollIntervalMs) {
            currentPlayback = apiClient.getCurrentPlayback();
            lastFetchMs = now;
        }
    }

    private void drawCard(class_332 drawContext) {
        class_310 client = class_310.method_1551();
        int x = config.hudX;
        int y = config.hudY;
        int width = config.cardWidth;
        int height = config.cardHeight;

        drawContext.method_25294(x, y, x + width, y + height, 0xB0111111);
        drawContext.method_25294(x, y, x + width, y + 1, 0xFF2A2A2A);
        drawContext.method_25294(x, y + height - 1, x + width, y + height, 0xFF2A2A2A);

        int artX = x + 8;
        int artY = y + 8;
        class_2960 albumArt = AlbumArtTextureCache.getTexture(currentPlayback.getAlbumArtUrl());
        if (albumArt != null) {
            drawContext.method_25290(albumArt, artX, artY, 0, 0, COVER_SIZE, COVER_SIZE, COVER_SIZE, COVER_SIZE);
        } else {
            drawContext.method_25294(artX, artY, artX + COVER_SIZE, artY + COVER_SIZE, 0xFF1B1B1B);
            drawContext.method_27534(client.field_1772, class_2561.method_43470("♪"), artX + COVER_SIZE / 2, artY + 22, 0xFFFFFFFF);
        }

        int textX = artX + COVER_SIZE + 12;
        int textY = y + 18;
        String title = currentPlayback.getTrackName();
        String artist = currentPlayback.getArtistName();
        drawContext.method_27535(client.field_1772, class_2561.method_43470(title), textX, textY, 0xFFFFFFFF);
        drawContext.method_27535(client.field_1772, class_2561.method_43470(artist), textX, textY + 18, 0xFFB0B0B0);

        int barX = textX;
        int barY = y + 52;
        int barWidth = width - (textX - x) - 12;
        float progressRatio = currentPlayback.getDurationMs() > 0 ? (float) currentPlayback.getProgressMs() / currentPlayback.getDurationMs() : 0.0F;
        drawContext.method_25294(barX, barY, barX + barWidth, barY + 4, 0xFF2A2A2A);
        drawContext.method_25294(barX, barY, barX + Math.round(barWidth * progressRatio), barY + 4, 0xFF1DB954);

        long elapsed = Math.min(currentPlayback.getProgressMs(), currentPlayback.getDurationMs());
        long total = currentPlayback.getDurationMs();
        drawContext.method_27535(client.field_1772, class_2561.method_43470(formatDuration(elapsed)), barX, barY + 10, 0xFFB8B8B8);
        drawContext.method_27535(client.field_1772, class_2561.method_43470(formatDuration(total)), x + width - 16 - client.field_1772.method_1727(formatDuration(total)), barY + 10, 0xFFB8B8B8);
    }

    private void drawEmptyState(class_332 drawContext) {
        class_310 client = class_310.method_1551();
        int x = config.hudX;
        int y = config.hudY;
        int width = 220;
        int height = 52;

        drawContext.method_25294(x, y, x + width, y + height, 0xB0111111);
        drawContext.method_27535(client.field_1772, class_2561.method_43470("Nothing playing"), x + 12, y + 18, 0xFFFFFFFF);
        drawContext.method_27535(client.field_1772, class_2561.method_43470("Run /spotify login"), x + 12, y + 30, 0xFFB0B0B0);
    }

    private static String formatDuration(long ms) {
        long seconds = Math.max(0L, ms / 1000L);
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;
        return String.format("%d:%02d", minutes, remainingSeconds);
    }
}
