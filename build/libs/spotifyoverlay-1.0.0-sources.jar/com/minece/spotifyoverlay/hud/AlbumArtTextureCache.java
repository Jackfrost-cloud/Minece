package com.minece.spotifyoverlay.hud;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class AlbumArtTextureCache {
    private static final Map<String, class_2960> CACHE = new HashMap<>();

    public static class_2960 getTexture(String url) {
        if (url == null || url.isBlank()) {
            return null;
        }

        if (CACHE.containsKey(url)) {
            return CACHE.get(url);
        }

        try {
            byte[] bytes = download(url);
            if (bytes.length == 0) {
                return null;
            }

            try (ByteArrayInputStream in = new ByteArrayInputStream(bytes)) {
                class_1011 nativeImage = class_1011.method_4309(in);
                class_2960 identifier = new class_2960("spotifyoverlay", "album_art_" + Integer.toHexString(url.hashCode()));
                class_310.method_1551().method_1531().method_4616(identifier, new class_1043(nativeImage));
                CACHE.put(url, identifier);
                return identifier;
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] download(String url) throws IOException {
        try (InputStream inputStream = new URL(url).openStream()) {
            return inputStream.readAllBytes();
        }
    }
}
